#include<iostream>
using namespace std;
int main() {
	long long int s, d;
	while (cin >> s >> d) {
		long long int p = 0;
		while (p < d) {
			p += s;
			if (p >= d)
				break;
			++s;
			
		}
		cout << s << endl;
	}
}
