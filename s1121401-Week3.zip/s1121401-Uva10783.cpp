#include<iostream>
using namespace std;
int main(){
	int testcase{},casetime=1;
	cin >> testcase;

	while (testcase > 0) {
		int a, b,sum=0;
		cin >> a >> b;
		if (a %2 != 0) {
			while (a <= b) {
				sum += a;
				a += 2;
			}
		}
		else {
			++a;
			while (a <= b) {
				sum += a;
				a += 2;
			}
		}
		cout << "Case " << casetime << ": " << sum<<endl;
		--testcase;
		++casetime;
	}
}